package com.promosim.gestionparc.enums;

public enum VehicleType {
    TRUCK,
    CAR,
    VAN,
}
