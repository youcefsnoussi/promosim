package com.promosim.gestionparc.enums;

public enum FuelType {
    GASOLINE,
    DIESEL,
    ELECTRIC,
    HYBRID,
}
