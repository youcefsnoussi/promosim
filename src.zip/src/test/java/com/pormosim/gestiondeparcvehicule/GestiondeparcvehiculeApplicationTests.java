package com.pormosim.gestiondeparcvehicule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestiondeparcvehiculeApplicationTests {

	@Test
	void contextLoads() {
	}

}
